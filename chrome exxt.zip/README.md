# TEMPLATE CE INFORMATION

## Getting started

npm -v = 9.3.1

Node.js v18.14.1

## Installation
npm run watch

## Usage
1. Go to Chrome Settings using three dots on the top right corner.
2. Now, Enable developer mode.
3. Click on Load Unpacked and select your Build folder - Note: You need to select the folder in which the manifest file exists. ...
4. The extension will be installed now.

#   l a d y - n a t a l i e - c e  
 